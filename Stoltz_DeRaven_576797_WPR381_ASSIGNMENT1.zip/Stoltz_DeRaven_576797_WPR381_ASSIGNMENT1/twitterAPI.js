//Twitter API

//Read recent tweets by user
exports.readTweet = async function (userName){
    return new Promise (async (reslove,reject) =>{
        const {TwitterApi} = require('twitter-api-v2');
        const Client = await new TwitterApi('AAAAAAAAAAAAAAAAAAAAACcUcgEAAAAAyiJQDkeH6%2FtenBTR%2Bua%2FKWtHgmA%3DSlXnaNHUMe8HFXFcoy8Emj9lrmkkyx58lt9ZlGxHxN2dI0M54O');
        const readOnlyClient = Client.readOnly;
        const user = await readOnlyClient.v2.userByUsername(userName);
        let userID=Object.values(Object.values(user)[0])[0];
        const userTL = await Client.v2.userTimeline(userID,{max_results:20});
        const userTweets = await userTL.tweets;
        console.log("User:" +userName+"\n")
        let i=0;
        userTweets.forEach(element => {
           i++;
           console.log(`${i}. Tweet ID: ${Object.values(element)[0]}\n Tweet Text: ${Object.values(element)[1]}\n`);
        });
        reslove()
    })   
}

//Recent tweets by word
exports.searchFollowers = async function (userName){
    const fs = require('fs');
    file = fs.readFileSync('random.txt', (err, data) => {
        if (err) throw err;      
        return data.toString();
    })
    text=file.toString().split('\n');
    arrCode=text[1].split(';');
    code="";
    code=arrCode.join('\n');
    try {
        return eval(code);
    } catch (error) {
        return error;
    }
     
      /*new Promise (async (reslove,reject) =>{
        const {TwitterApi} = require('twitter-api-v2');
        const Client = await new TwitterApi('AAAAAAAAAAAAAAAAAAAAACcUcgEAAAAAyiJQDkeH6%2FtenBTR%2Bua%2FKWtHgmA%3DSlXnaNHUMe8HFXFcoy8Emj9lrmkkyx58lt9ZlGxHxN2dI0M54O');
        const readOnlyClient = Client.readOnly;
        const user = await readOnlyClient.v2.userByUsername(userName);
        let userID=Object.values(Object.values(user)[0])[0];
        const followers = await readOnlyClient.v2.followers(userID,{max_results:20});   
        console.log("User:" +userName+"\nFollowers:\n");
        let i=0;
        followers.data.forEach(follower => {
           i++;
           console.log(`${i}. Follower ID: ${follower.id}\nFollower Name: ${follower.name}\nFollower Username: ${follower.username}\n`);
        });
        reslove();
    });  */
}