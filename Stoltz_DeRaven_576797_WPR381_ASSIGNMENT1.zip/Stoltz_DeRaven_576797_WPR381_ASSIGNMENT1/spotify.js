exports.findTrack= async function (track) {  //Searching for specific spotify track
    return new Promise(async (resolve,reject)=> {
        const Spotify = require('./node_modules/spotify-finder');
        const spotifyClient = new Spotify({
            consumer: {
                key:'2c73810c2fa54965b080f49fd3b1ff4b',
                secret: 'd44b8c4cadb54ffb84db08d50531f3e2' 
            }
        })
        await spotifyClient.search({q:track,type:'track',limit:"1"},function (err,data) {
            if (err) throw err;
            if (data===undefined){
                console.log("ID not found")  ;
            }       
            else {
                let artists= [];
                let i=0;
                data.tracks.items[0].artists.forEach(artist => {
                i++;
                artists[i]=artist.name;
            });
            console.log("Artists:" + artists.join(','));       
            console.log("Song Name:" + data.tracks.items[0].name);
            console.log("Preview Link:" + data.tracks.items[0].preview_url);
            console.log("Album Name:" + data.tracks.items[0].album.name);   
        }
    });
        resolve();
    }) 
}

exports.findAlbum = async function (album) {  //reading file to excecute the code to search for a specific album's information
    const fs = require('fs');
    file = fs.readFileSync('random.txt', (err, data) => {
        if (err) throw err;      
        return data.toString();
    })
    text=file.toString().split('\n');
    arrCode=text[0].split(';')
    code="";
    code=arrCode.join('\n')
    return eval(code)   
}

