const run =require('./generateMenu.js');
run.generateMenu();
