exports.generateMenu = async function () {   
    return new Promise(async ()=>{
        bcontinue = true;
    while (bcontinue) {
      console.log("==============================");
      console.log("Enter 1. for Twitter Tweets");
      console.log("Enter 2. for Spotify Song");
      console.log("Enter 3. for Textfile Queries");
      console.log("Enter 0. to exit");
      console.log("==============================");
      let op=0;
        const readln = require('readline-sync');
        op=parseInt(readln.question('Enter Option: ', {}))
        console.log("==============================");
     switch (op) {
        case 1:
          const twit = require('./twitterAPI.js');
          let user=readln.question('Enter User ID:',{});
          let isnum = /^\d+$/.test(user);//Testing if string is only a number
          if (isnum) {
              console.log("Username cannot contain only numbers");
              continue;
          }
          await twit.readTweet(user);       
            break;
        case 2:
          const spot = require('./spotify.js');
          await spot.findTrack(readln.question('Enter Song Name:',{}));  
            break;
        case 3:
            console.log("==============================");
            console.log("Enter 1. to search for Spotify Album");
            console.log("Enter 2. to return followers of a specified user");
            console.log("Enter 0. to go back");
            console.log("==============================");
            const readln2 = require('readline-sync');
            let op2=parseInt(readln2.question('Enter Option: ', {}))
            console.log("==============================");
            switch (op2) {
                case 1:
                    const spot2 = require('./spotify.js');
                    let album =readln.question('Enter Album Name:',{})
                    if (album) {
                        
                    }
                    await spot2.findAlbum(album);
                    
                    continue;  
                case 2:
                    const twit2 = require('./twitterAPI.js');
                    let user =readln.question('Enter User to search for:',{});
                    let isnum = /^\d+$/.test(user);//Testing if string is only a number
                    if (isnum) {
                        console.log("Username cannot contain only numbers");
                        continue;
                    }
                    await twit2.searchFollowers(user);
                    continue;

                case 0:
                    continue;
                
                default:
                    console.log("invalid Input")
                    continue;
            }
        case 0:
            bcontinue = false;
            break;
        default:
            console.log("Invalid option");
            break;
    }     
  }
})    
}